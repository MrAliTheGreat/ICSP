// STRUCTS

struct Product
{
	char* name;
	char* seller_username;
	int quantity;
	float price;
};

struct Seller
{
	char* username;
	char* password;
	float money;
	struct Product** seller_products;
	int num_products;
};

struct Buyer
{
	char* username;
	char* password;
	float money;
	struct Product** buyer_products;
	int num_products;
};

struct Shop
{
	struct Seller** Sellers;
	struct Buyer** Buyers;
	struct Product** Products;
	struct Buyer* online_buyer;
	struct Seller* online_seller;
	int num_buyers, num_sellers, num_products;
};

// FUNCTIONS

char** get_input();

struct Shop* create_shop();

void signup(struct Shop* UTKala , char* username, char* password, char* user_type);

void login(struct Shop* UTKala, char* username, char* password, char* user_type);

void logout(struct Shop* UTKala);

void deposit(struct Shop* UTKala, int deposit_amount);

void add_goods(struct Shop* UTKala, char* goods_name, int goods_price, int goods_count);

void buy(struct Shop* UTKala, char* goods_name, int goods_count, char* seller_username);

void show_goods(struct Shop* UTKala);

void view(struct Shop* UTKala);

void exit_shop(struct Shop* UTKala);

int check_buyer_existence(struct Buyer** Buyers, int num_buyers, char* username);

int check_seller_existence(struct Seller** Sellers, int num_sellers, char* username);

int check_product_existence(struct Product** Products, int num_products, char* goods_name, char* online_seller_username);

void increse_seller_money(struct Shop* UTKala, char* seller_username, float amount);