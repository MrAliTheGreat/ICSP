#include <stdio.h>
#include <string.h>

#include "Headers.h"

int check_buyer_existence(struct Buyer** Buyers, int num_buyers, char* username){
	// Check whether seller already exists or not
	for (int i = 0; i < num_buyers; i++){
		if (!strcmp((*(Buyers + i))->username, username)){
			return 1;
		}
	}
	return 0;
}