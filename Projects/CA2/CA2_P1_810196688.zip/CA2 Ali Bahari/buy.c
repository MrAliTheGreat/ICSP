#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Headers.h"

void buy(struct Shop* UTKala, char* goods_name, int goods_count, char* seller_username){
	// Checking status of product
	int product_status = check_product_existence(UTKala->Products, UTKala->num_products, goods_name, seller_username);
	// Adding product
	if (product_status >= 0){
		// Checking for negative value
		if (goods_count >= 0){
			// checking whether the quantity that buyer wants is available or not 
			if (UTKala->Products[product_status]->quantity >= goods_count){
				// Checking if buyer's money is enough of not
				if (UTKala->online_buyer->money >= UTKala->Products[product_status]->price * goods_count){
					// New product
					struct Product* new_user_product = malloc(sizeof(struct Product));
					new_user_product->name = goods_name;
					new_user_product->price = UTKala->Products[product_status]->price;
					new_user_product->quantity = goods_count;
					new_user_product->seller_username = seller_username;

					// Decreasing product quantity
					UTKala->Products[product_status]->quantity -= goods_count;

					// Updating memory and adding product to buyer's bought list 
					UTKala->online_buyer->num_products++;
					UTKala->online_buyer->buyer_products = realloc(UTKala->online_buyer->buyer_products, UTKala->online_buyer->num_products * sizeof(struct Product*));
					UTKala->online_buyer->buyer_products[UTKala->online_buyer->num_products - 1] = new_user_product;

					// Decreasing buyer money
					UTKala->online_buyer->money -= UTKala->Products[product_status]->price * goods_count;

					// increasing seller money
					increse_seller_money(UTKala, seller_username, UTKala->Products[product_status]->price * goods_count);
					// Success message
					printf("Transaction Done Successfully!\n");
				}
				// Not enough money
				else{
					printf("You Don't Have Enough Money!\n");
				}
			}
			// Quantity is less than wanted
			else{
				printf("Product Quantity Is Less Than Your Request!\n");
			}
		}
		// Negative value is invalid
		else{
			printf("Invalid Product Quantity For Buying!\n");
		}
	}
	// Product doesn't exist
	else{
		printf("Product Not Found!\n");
	}
}