#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Headers.h"

void signup(struct Shop* UTKala , char* username, char* password, char* user_type){
	// Checking the role , examining existence of the username for checking uniqueness and checking if a user is online or not
	if (!strcmp(user_type, "buyer") && !check_buyer_existence(UTKala->Buyers, UTKala->num_buyers, username) && (UTKala->online_buyer == NULL && UTKala->online_seller == NULL)){
		// Creating a new buyer
		struct Buyer* new_buyer = malloc(sizeof(struct Buyer));
		new_buyer->username = username;
		new_buyer->password = password;
		new_buyer->money = 0;
		new_buyer->buyer_products = malloc(sizeof(struct Product*));
		new_buyer->buyer_products[0] = NULL;
		new_buyer->num_products = 0;
		// Updating memory size for the new Buyer and adding the Buyer to shop's buyers
		UTKala->num_buyers++;
		UTKala->Buyers = realloc(UTKala->Buyers, UTKala->num_buyers * sizeof(struct Buyer*));
		UTKala->Buyers[UTKala->num_buyers - 1] = new_buyer;
		// Printing success message
		printf("New Buyer Signed Up Successfully!\n");
	}
	else if (!strcmp(user_type, "seller") && !check_seller_existence(UTKala->Sellers, UTKala->num_sellers, username) && (UTKala->online_buyer == NULL && UTKala->online_seller == NULL)){
		// Creating a new seller
		struct Seller* new_seller = malloc(sizeof(struct Seller));
		new_seller->username = username;
		new_seller->password = password;
		new_seller->money = 0;
		new_seller->seller_products = malloc(sizeof(struct Product*));
		new_seller->seller_products[0] = NULL;
		new_seller->num_products = 0;
		// Updating memory size for the new Seller and adding the Seller to shop's sellers
		UTKala->num_sellers++;
		UTKala->Sellers = realloc(UTKala->Sellers, UTKala->num_sellers * sizeof(struct Seller*));
		UTKala->Sellers[UTKala->num_sellers - 1] = new_seller;
		// Printing success message
		printf("New Seller Signed Up Successfully!\n");
	}
	// If a user is online you can't signup the online user has to sign out so fail message is shown 
	else if (UTKala->online_buyer != NULL || UTKala->online_seller != NULL){
		printf("A User Has Logged In, You Can't Sign Up Until That User Logs Out!\n");
	}
	// Already existing user violation of uniqueness
	else{
		printf("User Already Exists!\n");
	}
}