#include <stdio.h>
#include <string.h>

#include "Headers.h"

int check_seller_existence(struct Seller** Seller, int num_sellers, char* username){
	// Check whether the seller already exists or not
	for (int i = 0; i < num_sellers; i++){
		if (!strcmp((*(Seller + i))->username, username)){
			return 1;
		}
	}
	return 0;
}