#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Headers.h"

void login(struct Shop* UTKala, char* username, char* password, char* user_type){
	// Checking role , existence for uniqueness and if a user is online or not
	if (!strcmp(user_type, "buyer") && check_buyer_existence(UTKala->Buyers, UTKala->num_buyers, username) && (UTKala->online_buyer == NULL && UTKala->online_seller == NULL)){
		// Finding the buyer
		for (int i = 0; i < UTKala->num_buyers; i++){
			// making the buyer go online
			if (!strcmp( (*(UTKala->Buyers + i))->username , username) ){
				if (!strcmp((*(UTKala->Buyers + i))->password, password)){
					UTKala->online_buyer = *(UTKala->Buyers + i);
					// Success Message
					printf("Buyer Logged In Successfully!\n");
				}
				// Password not matching the input of function
				else{
					printf("Entered Password Doesn't Match!\n");
				}
			}
		}
	}
	// Checking role , existence for uniqueness and if a user is online or not for the seller
	else if (!strcmp(user_type, "seller") && check_seller_existence(UTKala->Sellers, UTKala->num_sellers, username) && (UTKala->online_buyer == NULL && UTKala->online_seller == NULL)){
		// Finding the seller
		for (int i = 0; i < UTKala->num_sellers; i++){
			// making the seller go online
			if (!strcmp((*(UTKala->Sellers + i))->username, username)){
				if (!strcmp((*(UTKala->Sellers + i))->password, password)){
					UTKala->online_seller = *(UTKala->Sellers + i);
					// Success Message
					printf("Seller Logged In Successfully!\n");
				}
				else{
					// Password not matching the input of function
					printf("Entered Password Doesn't Match!\n");
				}
			}
		}
	}
	// If another user is online we can't login until that user logs out so printing fail message
	else if (UTKala->online_buyer != NULL || UTKala->online_seller != NULL){
		printf("A User Has Logged In You Can't Log In!\n");
	}
	// Not finding the message 
	else{
		printf("User Not Found!\n");
	}
}