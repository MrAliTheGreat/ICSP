#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Headers.h"

void view(struct Shop* UTKala){
	// buyer is online
	if (UTKala->online_buyer != NULL && UTKala->online_seller == NULL){
		// Printing an indicator
		printf("Username | Role | Balance\n");
		// Printing info
		printf("%s | buyer | %.2f\n" , UTKala->online_buyer->username , UTKala->online_buyer->money);
		// Printing an indicator
		printf("\nProduct Name | Product Unit Price | Bought Product Quantity | Seller Name\n");
		for (int i = 0; i < UTKala->online_buyer->num_products; i++){
			// Printing info
			printf("%s | %.2f | %d | %s\n", UTKala->online_buyer->buyer_products[i]->name, UTKala->online_buyer->buyer_products[i]->price, UTKala->online_buyer->buyer_products[i]->quantity, UTKala->online_buyer->buyer_products[i]->seller_username);
		}
	}
	// seller is online
	else if (UTKala->online_buyer == NULL && UTKala->online_seller != NULL){
		// Printing an indicator
		printf("Username | Role | Balance\n");
		// Printing info
		printf("%s | seller | %.2f\n", UTKala->online_seller->username, UTKala->online_seller->money);
		// Printing an indicator
		printf("\nProduct Name | Product Unit Price | Product Quantity\n");
		for (int i = 0; i < UTKala->online_seller->num_products; i++){
			// Printing info
			printf("%s | %.2f | %d\n", UTKala->online_seller->seller_products[i]->name, UTKala->online_seller->seller_products[i]->price, UTKala->online_seller->seller_products[i]->quantity);
		}
	}
	// No user is online
	else{
		printf("No User Has Logged In!\n");
	}
}