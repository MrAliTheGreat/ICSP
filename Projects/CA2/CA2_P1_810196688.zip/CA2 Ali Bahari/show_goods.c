#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Headers.h"

void show_goods(struct Shop* UTKala){
	// Some user has to be logged in for this command to work
	if (UTKala->online_buyer != NULL || UTKala->online_seller != NULL){
		// Printing an indicator
		printf("Seller Name | Product Name | Product Unit Price | Product Quantity\n");
		for (int i = 0; i < UTKala->num_products; i++){
			// Printing the info
			printf("%s | %s | %.2f | %d\n", UTKala->Products[i]->seller_username, UTKala->Products[i]->name, UTKala->Products[i]->price, UTKala->Products[i]->quantity);
		}
	}
	// No user is logged in
	else{
		printf("No User Has Logged In!\n");
	}
}