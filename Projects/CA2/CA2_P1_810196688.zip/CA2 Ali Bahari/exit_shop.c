#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Headers.h"

void exit_shop(struct Shop* UTKala){
	// Freeing all the memory used for products in the shop
	// Freeing all Products of shop will also free the pointers in seller's Products because they're the same
	for (int i = 0; i < UTKala->num_products; i++){
		free(UTKala->Products[i]->name);
		free(UTKala->Products[i]);
	}
	free(UTKala->Products);

	// Freeing all the memory used for buyers in the shop
	for (int i = 0; i < UTKala->num_buyers; i++){
		for (int j = 0; j < UTKala->Buyers[i]->num_products; j++){
			free(UTKala->Buyers[i]->buyer_products[j]->name);
			free(UTKala->Buyers[i]->buyer_products[j]);
		}
		free(UTKala->Buyers[i]->buyer_products);
		free(UTKala->Buyers[i]->username);
		free(UTKala->Buyers[i]->password);
		free(UTKala->Buyers[i]);
	}
	free(UTKala->Buyers);

	// Freeing all the memory used for sellers in the shop
	for (int i = 0; i < UTKala->num_sellers; i++){
		free(UTKala->Sellers[i]->username);
		free(UTKala->Sellers[i]->password);
		free(UTKala->Sellers[i]);
	}
	free(UTKala->Sellers);

	// Freeing all the memory used for online users in the shop
	free(UTKala->online_buyer);
	free(UTKala->online_seller);
	// Success Message
	printf("\nFreed All Memory and Exited Successfully!\n");
}