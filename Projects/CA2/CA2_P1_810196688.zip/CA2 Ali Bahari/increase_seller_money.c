#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Headers.h"

void increse_seller_money(struct Shop* UTKala, char* seller_username, float amount){
	// Finding the seller by username and increasing its balance
	for (int i = 0; i < UTKala->num_sellers; i++){
		if (!strcmp(UTKala->Sellers[i]->username, seller_username)){
			UTKala->Sellers[i]->money += amount;
		}
	}
}